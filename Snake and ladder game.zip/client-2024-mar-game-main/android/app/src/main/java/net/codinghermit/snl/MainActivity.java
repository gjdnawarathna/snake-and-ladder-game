package net.codinghermit.snl;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
