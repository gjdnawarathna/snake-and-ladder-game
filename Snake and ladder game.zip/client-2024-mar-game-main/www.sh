#!/usr/bin/env bash

rsync -a build/ app/www
