#!/usr/bin/env bash

NODE_ENV=prod CAPACITOR_ANDROID_STUDIO_PATH=/run/current-system/sw/bin/android-studio cap sync
